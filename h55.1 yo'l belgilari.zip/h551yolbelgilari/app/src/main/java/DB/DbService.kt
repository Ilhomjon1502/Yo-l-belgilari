package DB

import Models.Belgi

interface DbService {
    fun addOgohlantiruvchiBelgi(belgi: Belgi)
    fun editOgohlantiruvchiBelgi(belgi: Belgi):Int
    fun deleteOgohlantiruvchiBelgi(belgi: Belgi)
    fun getAllOgohlantiruvchiBelgi():ArrayList<Belgi>

    fun addImtioyzliBelgi(belgi: Belgi)
    fun editImtioyzliBelgi(belgi: Belgi):Int
    fun deleteImtioyzliBelgi(belgi: Belgi)
    fun getAllImtioyzliBelgi(): ArrayList<Belgi>

    fun addTaqiqlovchiBelgi(belgi: Belgi)
    fun editTaqiqlovchiBelgi(belgi: Belgi):Int
    fun deleteTaqiqlovchiBelgi(belgi: Belgi)
    fun getAllTaqiqlovchiBelgi():ArrayList<Belgi>

    fun addBuyuruvchiBelgi(belgi: Belgi)
    fun editBuyuruvchiBelgi(belgi: Belgi):Int
    fun deleteBuyuruvchiBelgi(belgi: Belgi)
    fun getAllBuyuruvchiBelgi():ArrayList<Belgi>

}