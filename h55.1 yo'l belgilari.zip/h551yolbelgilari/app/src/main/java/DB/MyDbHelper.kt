package DB

import Models.Belgi
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class MyDbHelper(context: Context?)
    :SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION), DbService{

    companion object{
        const val DB_NAME = "belgi_db"
        const val DB_VERSION = 1

        const val TABLE_NAME_OGOH = "table_ogohlantiruvchi"
        const val ID_OGOH = "id"
        const val NAME_OGOH = "name"
        const val MATN_OGOH = "matn"
        const val IMAGE_OGOH = "image_path"
        const val LIKE_OGOH = "like"

        const val TABLE_NAME_IMTIYOZLI = "table_imtiyozli"
        const val ID_IMTIYOZLI = "id"
        const val NAME_IMTIYOZLI = "name"
        const val MATN_IMTIYOZLI = "matn"
        const val IMAGE_IMTIYOZLI = "image_path"
        const val LIKE_IMTIYOZLI = "like"

        const val TABLE_NAME_TAQIQ = "table_taqiqlovchi"
        const val ID_TAQIQ = "id"
        const val NAME_TAQIQ = "name"
        const val MATN_TAQIQ = "matn"
        const val IMAGE_TAQIQ = "image_path"
        const val LIKE_TAQIQ = "like"

        const val TABLE_NAME_BUYUR = "table_buyuruvchi"
        const val ID_BUYUR = "id"
        const val NAME_BUYUR = "name"
        const val MATN_BUYUR = "matn"
        const val IMAGE_BUYUR = "image_path"
        const val LIKE_BUYUR = "like"
    }

    override fun onCreate(db: SQLiteDatabase?) {
        val queryOgogh = "create table $TABLE_NAME_OGOH ($ID_OGOH integer not null primary key autoincrement unique, $NAME_OGOH text not null, $MATN_OGOH text not null, $IMAGE_OGOH text not null, $LIKE_OGOH integer not null)"
        val queryImtiyoz = "create table $TABLE_NAME_IMTIYOZLI ($ID_IMTIYOZLI integer not null primary key autoincrement unique, $NAME_IMTIYOZLI text not null, $MATN_IMTIYOZLI text not null, $IMAGE_IMTIYOZLI text not null, $LIKE_IMTIYOZLI integer not null)"
        val queryTaqiq = "create table $TABLE_NAME_TAQIQ ($ID_TAQIQ integer not null primary key autoincrement unique, $NAME_TAQIQ text not null, $MATN_TAQIQ text not null, $IMAGE_TAQIQ text not null, $LIKE_TAQIQ integer not null)"
        val queryBuyur = "create table $TABLE_NAME_BUYUR ($ID_BUYUR integer not null primary key autoincrement unique, $NAME_BUYUR text not null, $MATN_BUYUR text not null, $IMAGE_BUYUR text not null, $LIKE_BUYUR integer not null)"

        db?.execSQL(queryOgogh)
        db?.execSQL(queryImtiyoz)
        db?.execSQL(queryTaqiq)
        db?.execSQL(queryBuyur)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {

    }


    //ogohlantiruvchi belgi
    override fun addOgohlantiruvchiBelgi(belgi: Belgi) {
        val dataBase = this.writableDatabase
        val contentValue = ContentValues()
        contentValue.put(NAME_OGOH, belgi.name)
        contentValue.put(MATN_OGOH, belgi.matni)
        contentValue.put(IMAGE_OGOH, belgi.imagePath)
        contentValue.put(LIKE_OGOH, belgi.like)
        dataBase.insert(TABLE_NAME_OGOH, null, contentValue)
        dataBase.close()
    }

    override fun editOgohlantiruvchiBelgi(belgi: Belgi): Int {
        val database = this.writableDatabase
        val contentValue = ContentValues()
        contentValue.put(NAME_OGOH, belgi.name)
        contentValue.put(MATN_OGOH, belgi.matni)
        contentValue.put(IMAGE_OGOH, belgi.imagePath)
        contentValue.put(LIKE_OGOH, belgi.like)

        return database.update(TABLE_NAME_OGOH, contentValue, "$ID_OGOH = ?", arrayOf(belgi.id.toString()))
    }

    override fun deleteOgohlantiruvchiBelgi(belgi: Belgi) {
        val database = this.writableDatabase
        database.delete(TABLE_NAME_OGOH, "$ID_OGOH = ?", arrayOf("${belgi.id}"))
        database.close()
    }

    override fun getAllOgohlantiruvchiBelgi(): ArrayList<Belgi> {
        val list = ArrayList<Belgi>()
        val query = "select * from $TABLE_NAME_OGOH"
        val database = this.readableDatabase
        val cursor = database.rawQuery(query, null)

        if (cursor.moveToFirst()){
            do{
                val id = cursor.getInt(0)
                val name = cursor.getString(1)
                val matni = cursor.getString(2)
                val imagePath = cursor.getString(3)
                val like = cursor.getInt(4)
                val contact = Belgi(id, name, matni, imagePath, like)
                list.add(contact)
            }while (cursor.moveToNext())
        }
        return list
    }


    //IMTIYOZLI BELGI
    override fun addImtioyzliBelgi(belgi: Belgi) {
        val dataBase = this.writableDatabase
        val contentValue = ContentValues()
        contentValue.put(NAME_IMTIYOZLI, belgi.name)
        contentValue.put(MATN_IMTIYOZLI, belgi.matni)
        contentValue.put(IMAGE_IMTIYOZLI, belgi.imagePath)
        contentValue.put(LIKE_IMTIYOZLI, belgi.like)
        dataBase.insert(TABLE_NAME_IMTIYOZLI, null, contentValue)
        dataBase.close()
    }

    override fun editImtioyzliBelgi(belgi: Belgi): Int {
        val database = this.writableDatabase
        val contentValue = ContentValues()
        contentValue.put(NAME_IMTIYOZLI, belgi.name)
        contentValue.put(MATN_IMTIYOZLI, belgi.matni)
        contentValue.put(IMAGE_IMTIYOZLI, belgi.imagePath)
        contentValue.put(LIKE_IMTIYOZLI, belgi.like)

        return database.update(TABLE_NAME_IMTIYOZLI, contentValue, "$ID_IMTIYOZLI = ?", arrayOf(belgi.id.toString()))
    }

    override fun deleteImtioyzliBelgi(belgi: Belgi) {
        val database = this.writableDatabase
        database.delete(TABLE_NAME_IMTIYOZLI, "$ID_IMTIYOZLI = ?", arrayOf("${belgi.id}"))
        database.close()
    }

    override fun getAllImtioyzliBelgi(): ArrayList<Belgi> {
        val list = ArrayList<Belgi>()
        val query = "select * from $TABLE_NAME_IMTIYOZLI"
        val database = this.readableDatabase
        val cursor = database.rawQuery(query, null)

        if (cursor.moveToFirst()){
            do{
                val id = cursor.getInt(0)
                val name = cursor.getString(1)
                val matni = cursor.getString(2)
                val imagePath = cursor.getString(3)
                val like = cursor.getInt(4)
                val contact = Belgi(id, name, matni, imagePath, like)
                list.add(contact)
            }while (cursor.moveToNext())
        }
        return list
    }


    //taqiqlovchi belgi
    override fun addTaqiqlovchiBelgi(belgi: Belgi) {
        val dataBase = this.writableDatabase
        val contentValue = ContentValues()
        contentValue.put(NAME_TAQIQ, belgi.name)
        contentValue.put(MATN_TAQIQ, belgi.matni)
        contentValue.put(IMAGE_TAQIQ, belgi.imagePath)
        contentValue.put(LIKE_TAQIQ, belgi.like)
        dataBase.insert(TABLE_NAME_TAQIQ, null, contentValue)
        dataBase.close()
    }

    override fun editTaqiqlovchiBelgi(belgi: Belgi): Int {
        val database = this.writableDatabase
        val contentValue = ContentValues()
        contentValue.put(NAME_TAQIQ, belgi.name)
        contentValue.put(MATN_TAQIQ, belgi.matni)
        contentValue.put(IMAGE_TAQIQ, belgi.imagePath)
        contentValue.put(LIKE_TAQIQ, belgi.like)

        return database.update(TABLE_NAME_TAQIQ, contentValue, "$ID_TAQIQ = ?", arrayOf(belgi.id.toString()))
    }

    override fun deleteTaqiqlovchiBelgi(belgi: Belgi) {
        val database = this.writableDatabase
        database.delete(TABLE_NAME_TAQIQ, "$ID_TAQIQ = ?", arrayOf("${belgi.id}"))
        database.close()
    }

    override fun getAllTaqiqlovchiBelgi(): ArrayList<Belgi> {
        val list = ArrayList<Belgi>()
        val query = "select * from $TABLE_NAME_TAQIQ"
        val database = this.readableDatabase
        val cursor = database.rawQuery(query, null)

        if (cursor.moveToFirst()){
            do{
                val id = cursor.getInt(0)
                val name = cursor.getString(1)
                val matni = cursor.getString(2)
                val imagePath = cursor.getString(3)
                val like = cursor.getInt(4)
                val contact = Belgi(id, name, matni, imagePath, like)
                list.add(contact)
            }while (cursor.moveToNext())
        }
        return list
    }


    //buyuruvchi belgi
    override fun addBuyuruvchiBelgi(belgi: Belgi) {
        val dataBase = this.writableDatabase
        val contentValue = ContentValues()
        contentValue.put(NAME_BUYUR, belgi.name)
        contentValue.put(MATN_BUYUR, belgi.matni)
        contentValue.put(IMAGE_BUYUR, belgi.imagePath)
        contentValue.put(LIKE_BUYUR, belgi.like)
        dataBase.insert(TABLE_NAME_BUYUR, null, contentValue)
        dataBase.close()
    }

    override fun editBuyuruvchiBelgi(belgi: Belgi): Int {
        val database = this.writableDatabase
        val contentValue = ContentValues()
        contentValue.put(NAME_BUYUR, belgi.name)
        contentValue.put(MATN_BUYUR, belgi.matni)
        contentValue.put(IMAGE_BUYUR, belgi.imagePath)
        contentValue.put(LIKE_BUYUR, belgi.like)

        return database.update(TABLE_NAME_BUYUR, contentValue, "$ID_BUYUR = ?", arrayOf(belgi.id.toString()))
    }

    override fun deleteBuyuruvchiBelgi(belgi: Belgi) {
        val database = this.writableDatabase
        database.delete(TABLE_NAME_BUYUR, "$ID_BUYUR = ?", arrayOf("${belgi.id}"))
        database.close()
    }

    override fun getAllBuyuruvchiBelgi(): ArrayList<Belgi> {
        val list = ArrayList<Belgi>()
        val query = "select * from $TABLE_NAME_BUYUR"
        val database = this.readableDatabase
        val cursor = database.rawQuery(query, null)

        if (cursor.moveToFirst()){
            do{
                val id = cursor.getInt(0)
                val name = cursor.getString(1)
                val matni = cursor.getString(2)
                val imagePath = cursor.getString(3)
                val like = cursor.getInt(4)
                val contact = Belgi(id, name, matni, imagePath, like)
                list.add(contact)
            }while (cursor.moveToNext())
        }
        return list
    }
}