package Adapters

import DB.MyDbHelper
import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.mnsh.h551yolbelgilari.databinding.ItemVp2Binding
import kotlinx.android.synthetic.main.item_vp_2.view.*

class ViewPager2BelgiAdapter(val context: Context?, val rvItemClick: RvItemClick) : RecyclerView.Adapter<ViewPager2BelgiAdapter.Vh>() {

    inner class Vh(var itemView: ItemVp2Binding) : RecyclerView.ViewHolder(itemView.root) {
        fun onBind(position: Int) {
            when (position) {
                0-> itemView.rv_belgilar.adapter = RvAdapter(MyDbHelper(context).getAllOgohlantiruvchiBelgi(),0, rvItemClick)
                1-> itemView.rv_belgilar.adapter = RvAdapter(MyDbHelper(context).getAllImtioyzliBelgi(), 1, rvItemClick)
                2-> itemView.rv_belgilar.adapter = RvAdapter(MyDbHelper(context).getAllTaqiqlovchiBelgi(), 2, rvItemClick)
                3-> itemView.rv_belgilar.adapter = RvAdapter(MyDbHelper(context).getAllBuyuruvchiBelgi(), 3, rvItemClick)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Vh {
        return Vh(ItemVp2Binding.inflate(LayoutInflater.from(parent.context), parent, false))
    }

    override fun onBindViewHolder(holder: Vh, position: Int) {
        holder.onBind(position)
    }

    override fun getItemCount(): Int = 4
}